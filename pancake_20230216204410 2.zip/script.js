addEventListener('load', function(e) {
  document.querySelector('#test').innerHTML = 'pancake';
});